# fishing_system.py - pełna wersja GUI z PA, obrazkami, dźwiękiem
