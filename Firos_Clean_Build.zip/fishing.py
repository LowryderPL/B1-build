# główny system łowienia ryb
print('Fishing system ready')