# obsługa komendy /fish
print('Fish command handler')